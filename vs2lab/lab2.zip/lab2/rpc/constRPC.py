OK = '1'
APPEND = '2'
