import zmq
import const
import pickle
import sys
import string

# Nehme die Sätze entgegen, Splitte sie zu Wörter und sende diese nach einem Schema an die beiden Reducer
class Mapper:
	# Konstruktur
	def __init__(self, my_id):
		# ID des jeweiligen Mappers
		self.me = my_id
		# Kontext
		self.context = zmq.Context()
		# Pull Socket: Empfaenger
		self.pull_socket = self.context.socket(zmq.PULL)
		# Adresse
		self.address = "tcp://" + str(const.HOST) + ":" + str(const.PORT_SPLITTER)
		# Verbinden
		self.pull_socket.connect(self.address)
		# Die beiden Reducer: PushSocket, Addresse und Connecten
		self.push_socket_1 = self.context.socket(zmq.PUSH)
		self.push_socket_2 = self.context.socket(zmq.PUSH)
		self.reducer_address_1 = "tcp://" + str(const.HOST) + ":" + str(const.PORT_REDUCER)
		self.reducer_address_2 = "tcp://" + str(const.HOST) + ":" + str(const.PORT_REDUCER2)
		self.push_socket_1.connect(self.reducer_address_1)
		self.push_socket_2.connect(self.reducer_address_2)

	def run(self):
		# Warte Endlos
		while True:
			# Empfange die Daten von dem Splitter mittels einem Pull Socket
			data = pickle.loads(self.pull_socket.recv())
			# Kontrollausgabe das der Mapper etwas empfangen hat.
			print("\n\nMapper received: " + str(data[1]) + "\n")
			# Der zweite Teil des Tupels beinhaltet den Satz
			data = data[1]
			# Alles klein
			data = data.lower()
			# Keine Kommas
			data = data.replace(",", "")
			# Splitten das man Wörter hat. Words ist nun eine Liste mit den Wörter des Satzes
			words = data.split(" ")
			# Gehe die Wörter Liste durch (For Each Schleife)
			for word in words:
				# Ist die Länge des Wortes 0, so haben wir kein reales Wort also nehmen wir diese nicht.
				if len(word) > 0:
					# Schema: Alle Wörter die im Alphabet ein A - M haben, kommen zum Reducer 1
					if string.ascii_lowercase.index(word[0]) <= string.ascii_lowercase.index("m"):
						print("Mapper " + self.me + " sent to Reducer 1: " + word)
						self.push_socket_1.send(pickle.dumps((self.me, word)))
					# Schema: Alle Wörter die im Alphabet ein N - Z haben, kommen zum Reducer 2
					else:
						print("Mapper " + self.me + " sent to Reducer 2: " + word)
						self.push_socket_2.send(pickle.dumps((self.me, word)))

# Main Zeugs
mapper = Mapper(str(sys.argv[1]))
mapper.run()
