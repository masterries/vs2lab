#!/bin/sh
xterm -hold -e "python3 taskwork.py 1"&
xterm -hold -e "python3 taskwork.py 2"&
xterm -hold -e "python3 tasksrc.py 1" &
