#!/bin/sh
xterm -hold -e "python3 server.py"&
xterm -hold -e "python3 client.py"&
xterm -hold -e "python3 client1.py" &
