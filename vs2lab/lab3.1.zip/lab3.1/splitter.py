import zmq
import const 
import pickle
import lorem

# Nimmt eine Datei (falls keine Datei vorhanden erstelle selber ein Text) und Splitte die Sätze.
# Die Sätze sollen an Mapper gesendet werden
class Splitter:
	# Konstruktor
	# Falls in myFile nichts übergeben wurde, enthält diese Variable nicht eine TextDatei sondern
	# Einen BlindText
	def __init__(self, my_file=lorem.paragraph()):
		# Auszulesende File (Falls kein File übergeben ist, hat diese Variable den erzeugten Text
		self.my_file = my_file
		# Kontext
		self.context = zmq.Context()
		# Push Socket: Sender
		self.sender = self.context.socket(zmq.PUSH)
		# Addresse
		self.address = "tcp://" + str(const.HOST) + ":" + str(const.PORT_SPLITTER)
		# Binden
		self.sender.bind(self.address)
		# Satz Counter
		self.count = 0

	def run(self):
		# Ist die Filelänge größer als 20 kann es keine Textdatei sein
		# Somit haben wir den per Default erstellen BlindText in der Variable.
		# Speichere die gesplittete Sätze in der Variable sentences
		if len(self.my_file) > 20:
			sentences = self.my_file.split(".")
		# Im Else Fall müssen wir logischer Weise die andere Variante haben --> Textfile
		# Lese die Datei aus und Splitte ebenso die Texte nach Sätze
		else:
			file_to_open = open(self.my_file, "r")
			sentences = file_to_open.read().split(".")
		# Gehe die Sätze durch und sende diese gleichmäßig an den Mapper
		for i in range(len(sentences)-1):
			self.count += 1
			print(str(i) + ": " + sentences[i])
			self.sender.send(pickle.dumps(("Splitter", sentences[i])))

# Main Zeugs
splitter = Splitter()
print("Press a Button if the Mapper are ready")
_ = input()
splitter.run()

