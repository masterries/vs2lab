import zmq
import const 
import pickle
import lorem

# Nimmt eine Datei (falls keine Datei vorhanden erstelle selber ein Text) und Splitte die Sätze.
# Die Sätze sollen an Mapper gesendet werden
class Splitter:
	# Konstruktor
	# Falls in myFile nichts übergeben wurde, enthält diese Variable nicht eine TextDatei sondern
	# Einen BlindText
	def __init__(self, my_file=lorem.paragraph()):
		# Auszulesende File (Falls kein File übergeben ist, hat diese Variable den erzeugten Text
		self.my_file = my_file
		# Kontext
		self.context = zmq.Context()
		# Push Socket: Sender
		self.sender = self.context.socket(zmq.PUSH)
		# Addresse
		self.address = "tcp://" + str(const.HOST) + ":" + str(const.PORT_SPLITTER)
		# Binden
		self.sender.bind(self.address)
		# Satz Counter
		self.count = 0

	def run(self):
		print("Random text : ")
		print(self.my_file)
		print("_______________________")
		sentences = self.my_file.split(".")

		for i in range(len(sentences)-1):

			self.count += 1
			print(str(i) + ": " + sentences[i])
			self.sender.send(pickle.dumps(("Splitter", sentences[i])))

# Main Zeugs
splitter = Splitter()
print("Press a Button if the Mapper are ready")
_ = input()
splitter.run()

