import zmq
import const
import pickle
import sys
import os


# Reducer empfängt die Wörter vom Mapper und zählt diese. Nach jedem Wort gibt es eine List mit den Wörtern aus.
class Reducer: 
	# Konstruktor
	def __init__(self, my_id):
		# ID des Reducer
		self.me = my_id
		# Kontext
		self.context = zmq.Context()
		# Port auswählen (je nach ID)
		if my_id == "1": port = const.PORT_REDUCER
		else: port = const.PORT_REDUCER2
		# Verbindung erstellen
		self.pull_socket = self.context.socket(zmq.PULL)
		self.address = "tcp://" + str(const.HOST) + ":" + str(port)
		self.pull_socket.bind(self.address)
		self.wordcount = {}

		self.push_socket_1 = self.context.socket(zmq.PUSH)
		self.reducer_address_1 = "tcp://" + str(const.HOST) + ":" + str(const.PORT_REDUCER2)
		self.push_socket_1.connect(self.reducer_address_1)

	def run(self):
		while True:
			'''
			# Empfange die Wörter
			data = pickle.loads(self.pull_socket.recv())
			data = data[1]
			# Zahle Wort hoch, weil in Dict vorhanden
			if data in self.wordcount: self.wordcount[data] += 1
			# Wort nicht vorhanden: Setze Count auf 1
			else: self.wordcount[data] = 1
			# Kontrollausgabe
			print("\n\nReducer " + self.me + " received data: " + str(data) + " (Count: " + str(self.wordcount[data]) + ")\n")

			print(str(self.wordcount))
			'''
			if self.me == "1":

				# Empfange die Wörter
				data = pickle.loads(self.pull_socket.recv())
				data = data[1]

				# Zahle Wort hoch, weil in Dict vorhanden
				if data in const.WORDCOUNT_1: const.WORDCOUNT_1[data] += 1
				# Wort nicht vorhanden: Setze Count auf 1
				else: const.WORDCOUNT_1[data] = 1
				# Kontrollausgabe

				os.system('clear')		
				print("Reducer " + self.me + " received data: " + str(data) + " (Count: " + str(const.WORDCOUNT_1[data]) + ")")

				for x in const.WORDCOUNT_1:
					val = const.WORDCOUNT_1[x]
					print(x + "Count : " + str(val))

			else:
				# Empfange die Wörter
				data = pickle.loads(self.pull_socket.recv())
				data = data[1]

				# Zahle Wort hoch, weil in Dict vorhanden
				if data in const.WORDCOUNT_2: const.WORDCOUNT_2[data] += 1
				# Wort nicht vorhanden: Setze Count auf 1
				else: const.WORDCOUNT_2[data] = 1
				# Kontrollausgabe
				os.system('clear')
				print("Reducer " + self.me + " received data: " + str(data) + " (Count: " + str(const.WORDCOUNT_2[data]) + ")")

				for x in const.WORDCOUNT_2:
					val = const.WORDCOUNT_2[x]
					print(x + "Count : " + str(val))


reducer = Reducer(str(sys.argv[1]))
reducer.run()
