#!/bin/sh
xterm -hold -e "pipenv run python mapper.py 1" &
xterm -hold -e "pipenv run python mapper.py 2" &
xterm -hold -e "pipenv run python mapper.py 3" &
xterm -hold -e "pipenv run python reducer.py 1" &
xterm -hold -e "pipenv run python reducer.py 2" &
sleep 1
xterm -hold -e "pipenv run python splitter.py"
